# /etc/profile.d/qt5-themeing.sh - QT Themeing for Feren OS

if [[ "$DESKTOP_SESSION" == *"xfce" ]] || [[ "$DESKTOP_SESSION" == *"cinnamon" ]] || [[ "$DESKTOP_SESSION" == *"gnome" ]] || [[ "$DESKTOP_SESSION" == "gnome3" ]]; then
	export QT_QPA_PLATFORMTHEME=gtk2
else
	unset QT_QPA_PLATFORMTHEME
fi
