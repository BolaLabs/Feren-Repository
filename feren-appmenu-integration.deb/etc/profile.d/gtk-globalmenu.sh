# /etc/profile.d/gtk-globalmenu.sh - GTK Global Menu Support Fix for Feren OS with Plasma

if [[ "$DESKTOP_SESSION" == *"kde" ]] || [[ "$DESKTOP_SESSION" = *"plasma" ]]; then
	if [ -n "$GTK_MODULES" ]; then
		GTK_MODULES="${GTK_MODULES}:unity-gtk-module"
	else
		GTK_MODULES="unity-gtk-module"
	fi
	if [ -z "$UBUNTU_MENUPROXY" ]; then
		UBUNTU_MENUPROXY=1
	fi
	export GTK_MODULES
	export UBUNTU_MENUPROXY
else
	unset GTK_MODULES
	unset UBUNTU_MENUPROXY
fi
